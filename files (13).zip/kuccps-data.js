// EDUPATH AI DATABASE - 500 UNIQUE UNIVERSITY PROGRAMS
// Generated: 500 University | 50 KMTC | 200 TVET
// Total: 750 Programs

const UNIVERSITY_COURSES = [
  {
    "id": "UNI001",
    "name": "Bachelor of Medicine and Bachelor of Surgery",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 42,
    "minMeanGrade": "B+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5-6 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI002",
    "name": "Bachelor of Dental Surgery",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 41,
    "minMeanGrade": "B+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI003",
    "name": "Bachelor of Pharmacy",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI004",
    "name": "Bachelor of Science in Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI005",
    "name": "Bachelor of Science in Clinical Medicine",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI006",
    "name": "Bachelor of Science in Medical Laboratory Sciences",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI007",
    "name": "Bachelor of Science in Radiography",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI008",
    "name": "Bachelor of Science in Public Health",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI009",
    "name": "Bachelor of Science in Physiotherapy",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI010",
    "name": "Bachelor of Science in Nutrition and Dietetics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI011",
    "name": "Bachelor of Science in Anaesthesia",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI012",
    "name": "Bachelor of Science in Optometry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI013",
    "name": "Bachelor of Science in Occupational Therapy",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI014",
    "name": "Bachelor of Science in Speech Therapy",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI015",
    "name": "Bachelor of Science in Orthopaedic Trauma",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI016",
    "name": "Bachelor of Science in Critical Care Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI017",
    "name": "Bachelor of Science in Midwifery",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI018",
    "name": "Bachelor of Science in Emergency Medicine",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI019",
    "name": "Bachelor of Science in Respiratory Therapy",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI020",
    "name": "Bachelor of Science in Perfusion Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI021",
    "name": "Bachelor of Science in Cardiac Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI022",
    "name": "Bachelor of Science in Health Systems Management",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI023",
    "name": "Bachelor of Science in Health Records Management",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI024",
    "name": "Bachelor of Science in Pharmaceutical Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI025",
    "name": "Bachelor of Science in Biomedical Sciences",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI026",
    "name": "Bachelor of Science in Clinical Pathology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI027",
    "name": "Bachelor of Science in Nuclear Medicine",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI028",
    "name": "Bachelor of Science in Medical Imaging Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI029",
    "name": "Bachelor of Science in Cytotechnology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI030",
    "name": "Bachelor of Science in Histopathology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI031",
    "name": "Bachelor of Science in Clinical Psychology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI032",
    "name": "Bachelor of Science in Medical Microbiology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI033",
    "name": "Bachelor of Science in Dental Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI034",
    "name": "Bachelor of Science in Ophthalmology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI035",
    "name": "Bachelor of Science in Audiology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI036",
    "name": "Bachelor of Science in Prosthetics and Orthotics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI037",
    "name": "Bachelor of Science in Sonography",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI038",
    "name": "Bachelor of Science in Cardiovascular Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI039",
    "name": "Bachelor of Science in Neuroscience",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI040",
    "name": "Bachelor of Science in Pathology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI041",
    "name": "Bachelor of Science in Pharmacology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI042",
    "name": "Bachelor of Science in Toxicology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI043",
    "name": "Bachelor of Science in Clinical Nutrition",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI044",
    "name": "Bachelor of Science in Sports Medicine",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI045",
    "name": "Bachelor of Science in Pediatric Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI046",
    "name": "Bachelor of Science in Psychiatric Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI047",
    "name": "Bachelor of Science in Community Health Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI048",
    "name": "Bachelor of Science in Geriatric Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI049",
    "name": "Bachelor of Science in Oncology Nursing",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI050",
    "name": "Bachelor of Science in Nephrology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI051",
    "name": "Bachelor of Science in Dermatology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI052",
    "name": "Bachelor of Science in Urology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI053",
    "name": "Bachelor of Science in Gastroenterology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI054",
    "name": "Bachelor of Science in Endocrinology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI055",
    "name": "Bachelor of Science in Rheumatology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI056",
    "name": "Bachelor of Science in Immunology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI057",
    "name": "Bachelor of Science in Hematology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI058",
    "name": "Bachelor of Science in Medical Genetics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI059",
    "name": "Bachelor of Science in Reproductive Health",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI060",
    "name": "Bachelor of Science in Epidemiology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI061",
    "name": "Bachelor of Science in Health Education",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI062",
    "name": "Bachelor of Science in Biostatistics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI063",
    "name": "Bachelor of Science in Medical Informatics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI064",
    "name": "Bachelor of Science in Global Health",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI065",
    "name": "Bachelor of Science in Maternal Health",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI066",
    "name": "Bachelor of Science in Neonatology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI067",
    "name": "Bachelor of Science in Palliative Care",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI068",
    "name": "Bachelor of Science in Pain Management",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI069",
    "name": "Bachelor of Science in Infection Control",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI070",
    "name": "Bachelor of Science in Patient Safety",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI071",
    "name": "Bachelor of Science in Civil Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI072",
    "name": "Bachelor of Science in Mechanical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI073",
    "name": "Bachelor of Science in Electrical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI074",
    "name": "Bachelor of Science in Chemical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI075",
    "name": "Bachelor of Science in Computer Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI076",
    "name": "Bachelor of Science in Software Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI077",
    "name": "Bachelor of Science in Telecommunication Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI078",
    "name": "Bachelor of Science in Mechatronics Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI079",
    "name": "Bachelor of Science in Biomedical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI080",
    "name": "Bachelor of Science in Agricultural Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI081",
    "name": "Bachelor of Science in Mining Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI082",
    "name": "Bachelor of Science in Geospatial Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI083",
    "name": "Bachelor of Science in Petroleum Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI084",
    "name": "Bachelor of Science in Marine Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI085",
    "name": "Bachelor of Science in Aeronautical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI086",
    "name": "Bachelor of Science in Aerospace Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI087",
    "name": "Bachelor of Science in Nuclear Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI088",
    "name": "Bachelor of Science in Environmental Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI089",
    "name": "Bachelor of Science in Water Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI090",
    "name": "Bachelor of Science in Structural Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI091",
    "name": "Bachelor of Science in Highway Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI092",
    "name": "Bachelor of Science in Railway Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI093",
    "name": "Bachelor of Science in Bridge Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI094",
    "name": "Bachelor of Science in Coastal Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI095",
    "name": "Bachelor of Science in Tunnel Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI096",
    "name": "Bachelor of Science in Dam Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI097",
    "name": "Bachelor of Science in Construction Management",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI098",
    "name": "Bachelor of Science in Quantity Surveying",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI099",
    "name": "Bachelor of Science in Building Economics",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI100",
    "name": "Bachelor of Science in Real Estate Management",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI101",
    "name": "Bachelor of Science in Land Surveying",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI102",
    "name": "Bachelor of Science in Geomatics",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI103",
    "name": "Bachelor of Science in Photogrammetry",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI104",
    "name": "Bachelor of Science in Cartography",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI105",
    "name": "Bachelor of Science in Remote Sensing",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI106",
    "name": "Bachelor of Science in GIS",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI107",
    "name": "Bachelor of Science in Industrial Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI108",
    "name": "Bachelor of Science in Production Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI109",
    "name": "Bachelor of Science in Manufacturing Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI110",
    "name": "Bachelor of Science in Quality Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI111",
    "name": "Bachelor of Science in Systems Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI112",
    "name": "Bachelor of Science in Process Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI113",
    "name": "Bachelor of Science in Plant Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI114",
    "name": "Bachelor of Science in Maintenance Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI115",
    "name": "Bachelor of Science in Reliability Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI116",
    "name": "Bachelor of Science in Safety Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI117",
    "name": "Bachelor of Science in Fire Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI118",
    "name": "Bachelor of Science in Automotive Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI119",
    "name": "Bachelor of Science in Vehicle Design",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI120",
    "name": "Bachelor of Science in Engine Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI121",
    "name": "Bachelor of Science in Electrical Power Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI122",
    "name": "Bachelor of Science in Control Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI123",
    "name": "Bachelor of Science in Instrumentation Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI124",
    "name": "Bachelor of Science in Electronics Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI125",
    "name": "Bachelor of Science in Communication Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI126",
    "name": "Bachelor of Science in Signal Processing",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI127",
    "name": "Bachelor of Science in Microelectronics",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI128",
    "name": "Bachelor of Science in Embedded Systems",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI129",
    "name": "Bachelor of Science in Robotics Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI130",
    "name": "Bachelor of Science in Automation Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI131",
    "name": "Bachelor of Science in Renewable Energy Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI132",
    "name": "Bachelor of Science in Solar Energy Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI133",
    "name": "Bachelor of Science in Wind Energy Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI134",
    "name": "Bachelor of Science in Geothermal Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI135",
    "name": "Bachelor of Science in Hydropower Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI136",
    "name": "Bachelor of Science in Energy Systems Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI137",
    "name": "Bachelor of Science in Thermal Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI138",
    "name": "Bachelor of Science in HVAC Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI139",
    "name": "Bachelor of Science in Refrigeration Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI140",
    "name": "Bachelor of Science in Materials Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI141",
    "name": "Bachelor of Science in Metallurgical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI142",
    "name": "Bachelor of Science in Ceramic Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI143",
    "name": "Bachelor of Science in Polymer Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI144",
    "name": "Bachelor of Science in Composite Materials Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI145",
    "name": "Bachelor of Science in Nanotechnology Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI146",
    "name": "Bachelor of Science in Textile Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI147",
    "name": "Bachelor of Science in Leather Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI148",
    "name": "Bachelor of Science in Food Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI149",
    "name": "Bachelor of Science in Bioprocess Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI150",
    "name": "Bachelor of Science in Biochemical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 36,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI151",
    "name": "Bachelor of Science in Pharmaceutical Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 37,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI152",
    "name": "Bachelor of Science in Cosmetic Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI153",
    "name": "Bachelor of Science in Paper Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI154",
    "name": "Bachelor of Science in Pulp Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI155",
    "name": "Bachelor of Science in Printing Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI156",
    "name": "Bachelor of Science in Packaging Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI157",
    "name": "Bachelor of Science in Plastics Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI158",
    "name": "Bachelor of Science in Rubber Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI159",
    "name": "Bachelor of Science in Paint Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI160",
    "name": "Bachelor of Science in Adhesives Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI161",
    "name": "Bachelor of Science in Glass Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI162",
    "name": "Bachelor of Science in Cement Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI163",
    "name": "Bachelor of Science in Concrete Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI164",
    "name": "Bachelor of Science in Welding Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI165",
    "name": "Bachelor of Science in Corrosion Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI166",
    "name": "Bachelor of Science in Surface Engineering",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI167",
    "name": "Bachelor of Science in Coating Technology",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI168",
    "name": "Bachelor of Science in Computer Science",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI169",
    "name": "Bachelor of Science in Information Technology",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI170",
    "name": "Bachelor of Science in Information Systems",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI171",
    "name": "Bachelor of Science in Data Science",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI172",
    "name": "Bachelor of Science in Artificial Intelligence",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI173",
    "name": "Bachelor of Science in Machine Learning",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI174",
    "name": "Bachelor of Science in Deep Learning",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI175",
    "name": "Bachelor of Science in Cybersecurity",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI176",
    "name": "Bachelor of Science in Network Security",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI177",
    "name": "Bachelor of Science in Information Security",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI178",
    "name": "Bachelor of Science in Ethical Hacking",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI179",
    "name": "Bachelor of Science in Digital Forensics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI180",
    "name": "Bachelor of Science in Cloud Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI181",
    "name": "Bachelor of Science in Network Engineering",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI182",
    "name": "Bachelor of Science in Database Administration",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI183",
    "name": "Bachelor of Science in Web Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI184",
    "name": "Bachelor of Science in Mobile App Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI185",
    "name": "Bachelor of Science in Game Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI186",
    "name": "Bachelor of Science in Virtual Reality",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI187",
    "name": "Bachelor of Science in Augmented Reality",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI188",
    "name": "Bachelor of Science in Blockchain Technology",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI189",
    "name": "Bachelor of Science in Cryptocurrency Technology",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI190",
    "name": "Bachelor of Science in Internet of Things",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI191",
    "name": "Bachelor of Science in Big Data Analytics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI192",
    "name": "Bachelor of Science in Business Intelligence",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI193",
    "name": "Bachelor of Science in Data Analytics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI194",
    "name": "Bachelor of Science in Predictive Analytics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI195",
    "name": "Bachelor of Science in Data Mining",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI196",
    "name": "Bachelor of Science in Data Warehousing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI197",
    "name": "Bachelor of Science in DevOps Engineering",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI198",
    "name": "Bachelor of Science in System Administration",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI199",
    "name": "Bachelor of Science in Computer Networking",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI200",
    "name": "Bachelor of Science in Wireless Technology",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI201",
    "name": "Bachelor of Science in Telecommunications Technology",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI202",
    "name": "Bachelor of Science in Computer Graphics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI203",
    "name": "Bachelor of Science in Animation Technology",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI204",
    "name": "Bachelor of Science in Multimedia Systems",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI205",
    "name": "Bachelor of Science in Digital Media",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI206",
    "name": "Bachelor of Science in Human-Computer Interaction",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI207",
    "name": "Bachelor of Science in User Experience Design",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI208",
    "name": "Bachelor of Science in User Interface Design",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI209",
    "name": "Bachelor of Science in Software Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI210",
    "name": "Bachelor of Science in Software Testing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI211",
    "name": "Bachelor of Science in Quality Assurance",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI212",
    "name": "Bachelor of Science in Project Management (IT)",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI213",
    "name": "Bachelor of Science in IT Service Management",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI214",
    "name": "Bachelor of Science in Enterprise Architecture",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI215",
    "name": "Bachelor of Science in Business Analysis",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI216",
    "name": "Bachelor of Science in Systems Analysis",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI217",
    "name": "Bachelor of Science in Computer Vision",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI218",
    "name": "Bachelor of Science in Natural Language Processing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI219",
    "name": "Bachelor of Science in Speech Recognition",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI220",
    "name": "Bachelor of Science in Robotics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI221",
    "name": "Bachelor of Science in Autonomous Systems",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI222",
    "name": "Bachelor of Science in Quantum Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI223",
    "name": "Bachelor of Science in High Performance Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI224",
    "name": "Bachelor of Science in Parallel Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI225",
    "name": "Bachelor of Science in Distributed Systems",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI226",
    "name": "Bachelor of Science in Grid Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI227",
    "name": "Bachelor of Science in Edge Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI228",
    "name": "Bachelor of Science in Fog Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI229",
    "name": "Bachelor of Science in Serverless Computing",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI230",
    "name": "Bachelor of Science in Microservices Architecture",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI231",
    "name": "Bachelor of Science in API Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI232",
    "name": "Bachelor of Science in Full Stack Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI233",
    "name": "Bachelor of Science in Frontend Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI234",
    "name": "Bachelor of Science in Backend Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI235",
    "name": "Bachelor of Science in Progressive Web Apps",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI236",
    "name": "Bachelor of Science in React Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI237",
    "name": "Bachelor of Science in Angular Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI238",
    "name": "Bachelor of Science in Vue.js Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI239",
    "name": "Bachelor of Science in Node.js Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI240",
    "name": "Bachelor of Science in Python Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI241",
    "name": "Bachelor of Science in Java Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI242",
    "name": "Bachelor of Science in C++ Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI243",
    "name": "Bachelor of Science in Swift Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI244",
    "name": "Bachelor of Science in Kotlin Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI245",
    "name": "Bachelor of Science in Flutter Development",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI246",
    "name": "Bachelor of Business Administration",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI247",
    "name": "Bachelor of Commerce",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI248",
    "name": "Bachelor of Science in Accounting",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI249",
    "name": "Bachelor of Science in Finance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI250",
    "name": "Bachelor of Science in Actuarial Science",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI251",
    "name": "Bachelor of Arts in Economics",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI252",
    "name": "Bachelor of Science in Economics",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI253",
    "name": "Bachelor of Science in Marketing",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI254",
    "name": "Bachelor of Science in Human Resource Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI255",
    "name": "Bachelor of Science in Supply Chain Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI256",
    "name": "Bachelor of Science in Entrepreneurship",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI257",
    "name": "Bachelor of Laws",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI258",
    "name": "Bachelor of Science in Banking and Finance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI259",
    "name": "Bachelor of Science in Investment Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI260",
    "name": "Bachelor of Science in Financial Economics",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI261",
    "name": "Bachelor of Science in Risk Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI262",
    "name": "Bachelor of Science in Insurance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI263",
    "name": "Bachelor of Science in Real Estate",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI264",
    "name": "Bachelor of Science in Property Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI265",
    "name": "Bachelor of Science in Valuation",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI266",
    "name": "Bachelor of Science in Project Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI267",
    "name": "Bachelor of Science in Operations Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI268",
    "name": "Bachelor of Science in Logistics Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI269",
    "name": "Bachelor of Science in Procurement Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI270",
    "name": "Bachelor of Science in Transport Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI271",
    "name": "Bachelor of Science in Aviation Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI272",
    "name": "Bachelor of Science in Maritime Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI273",
    "name": "Bachelor of Science in Port Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI274",
    "name": "Bachelor of Science in Shipping Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI275",
    "name": "Bachelor of Science in Retail Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI276",
    "name": "Bachelor of Science in Sales Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI277",
    "name": "Bachelor of Science in Brand Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI278",
    "name": "Bachelor of Science in Digital Marketing",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI279",
    "name": "Bachelor of Science in Social Media Marketing",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI280",
    "name": "Bachelor of Science in Content Marketing",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI281",
    "name": "Bachelor of Science in E-commerce",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI282",
    "name": "Bachelor of Science in Business Analytics",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI283",
    "name": "Bachelor of Science in Business Intelligence",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI284",
    "name": "Bachelor of Science in Management Information Systems",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI285",
    "name": "Bachelor of Science in Strategic Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI286",
    "name": "Bachelor of Science in Corporate Governance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI287",
    "name": "Bachelor of Science in Public Administration",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI288",
    "name": "Bachelor of Science in Development Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI289",
    "name": "Bachelor of Science in International Business",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI290",
    "name": "Bachelor of Science in Global Business",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI291",
    "name": "Bachelor of Science in Trade",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI292",
    "name": "Bachelor of Science in Tourism Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI293",
    "name": "Bachelor of Science in Hotel Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI294",
    "name": "Bachelor of Science in Hospitality Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI295",
    "name": "Bachelor of Science in Event Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI296",
    "name": "Bachelor of Science in Catering Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI297",
    "name": "Bachelor of Science in Food and Beverage Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI298",
    "name": "Bachelor of Science in Restaurant Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI299",
    "name": "Bachelor of Science in Culinary Arts",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI300",
    "name": "Bachelor of Science in Pastry Arts",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI301",
    "name": "Bachelor of Science in Baking Technology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI302",
    "name": "Bachelor of Science in Quality Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI303",
    "name": "Bachelor of Science in Customer Service Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI304",
    "name": "Bachelor of Science in Service Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI305",
    "name": "Bachelor of Science in Change Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI306",
    "name": "Bachelor of Science in Leadership",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI307",
    "name": "Bachelor of Science in Organizational Development",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI308",
    "name": "Bachelor of Science in Training and Development",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI309",
    "name": "Bachelor of Science in Talent Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI310",
    "name": "Bachelor of Science in Compensation and Benefits",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI311",
    "name": "Bachelor of Science in Employee Relations",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI312",
    "name": "Bachelor of Science in Labor Relations",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI313",
    "name": "Bachelor of Science in Industrial Relations",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI314",
    "name": "Bachelor of Science in Forensic Accounting",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI315",
    "name": "Bachelor of Science in Taxation",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI316",
    "name": "Bachelor of Science in Auditing",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI317",
    "name": "Bachelor of Science in Cost Accounting",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI318",
    "name": "Bachelor of Science in Management Accounting",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI319",
    "name": "Bachelor of Science in Financial Accounting",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI320",
    "name": "Bachelor of Science in Public Finance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI321",
    "name": "Bachelor of Science in Corporate Finance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI322",
    "name": "Bachelor of Science in Islamic Finance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI323",
    "name": "Bachelor of Science in Microfinance",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI324",
    "name": "Bachelor of Science in Agriculture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI325",
    "name": "Bachelor of Science in Agribusiness",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI326",
    "name": "Bachelor of Science in Horticulture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI327",
    "name": "Bachelor of Veterinary Medicine",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 38,
    "minMeanGrade": "B-",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI328",
    "name": "Bachelor of Science in Food Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI329",
    "name": "Bachelor of Science in Biology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI330",
    "name": "Bachelor of Science in Biochemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI331",
    "name": "Bachelor of Science in Microbiology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI332",
    "name": "Bachelor of Science in Biotechnology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI333",
    "name": "Bachelor of Science in Molecular Biology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI334",
    "name": "Bachelor of Science in Cell Biology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI335",
    "name": "Bachelor of Science in Genetics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI336",
    "name": "Bachelor of Science in Botany",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI337",
    "name": "Bachelor of Science in Zoology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI338",
    "name": "Bachelor of Science in Ecology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI339",
    "name": "Bachelor of Science in Marine Biology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI340",
    "name": "Bachelor of Science in Environmental Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI341",
    "name": "Bachelor of Science in Wildlife Management",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI342",
    "name": "Bachelor of Science in Forestry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI343",
    "name": "Bachelor of Science in Fisheries",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI344",
    "name": "Bachelor of Science in Aquaculture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI345",
    "name": "Bachelor of Science in Soil Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI346",
    "name": "Bachelor of Science in Crop Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI347",
    "name": "Bachelor of Science in Animal Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI348",
    "name": "Bachelor of Science in Dairy Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI349",
    "name": "Bachelor of Science in Poultry Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI350",
    "name": "Bachelor of Science in Apiculture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI351",
    "name": "Bachelor of Science in Sericulture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI352",
    "name": "Bachelor of Science in Agricultural Economics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI353",
    "name": "Bachelor of Science in Agricultural Extension",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI354",
    "name": "Bachelor of Science in Agricultural Education",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI355",
    "name": "Bachelor of Science in Range Management",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI356",
    "name": "Bachelor of Science in Pasture Management",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI357",
    "name": "Bachelor of Science in Seed Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI358",
    "name": "Bachelor of Science in Plant Pathology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI359",
    "name": "Bachelor of Science in Entomology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI360",
    "name": "Bachelor of Science in Nematology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 31,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI361",
    "name": "Bachelor of Science in Weed Science",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI362",
    "name": "Bachelor of Science in Irrigation Engineering",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI363",
    "name": "Bachelor of Science in Land Reclamation",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI364",
    "name": "Bachelor of Science in Agroforestry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI365",
    "name": "Bachelor of Science in Organic Farming",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI366",
    "name": "Bachelor of Science in Sustainable Agriculture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI367",
    "name": "Bachelor of Science in Precision Agriculture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI368",
    "name": "Bachelor of Science in Urban Agriculture",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 29,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI369",
    "name": "Bachelor of Science in Vertical Farming",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI370",
    "name": "Bachelor of Science in Hydroponics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI371",
    "name": "Bachelor of Science in Aquaponics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI372",
    "name": "Bachelor of Science in Greenhouse Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI373",
    "name": "Bachelor of Science in Post-Harvest Technology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 30,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI374",
    "name": "Bachelor of Education (Arts)",
    "institution": "University",
    "cluster": 5,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI375",
    "name": "Bachelor of Education (Science)",
    "institution": "University",
    "cluster": 5,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI376",
    "name": "Bachelor of Education (Mathematics)",
    "institution": "University",
    "cluster": 5,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI377",
    "name": "Bachelor of Education (Languages)",
    "institution": "University",
    "cluster": 5,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI378",
    "name": "Bachelor of Education (ECD)",
    "institution": "University",
    "cluster": 5,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 22,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI379",
    "name": "Bachelor of Education (Special Needs)",
    "institution": "University",
    "cluster": 5,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI380",
    "name": "Bachelor of Arts in Psychology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI381",
    "name": "Bachelor of Arts in Sociology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI382",
    "name": "Bachelor of Arts in Political Science",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI383",
    "name": "Bachelor of Arts in Communication",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI384",
    "name": "Bachelor of Arts in Journalism",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI385",
    "name": "Bachelor of Arts in Public Relations",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI386",
    "name": "Bachelor of Arts in International Relations",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI387",
    "name": "Bachelor of Arts in Diplomacy",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI388",
    "name": "Bachelor of Arts in Development Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI389",
    "name": "Bachelor of Arts in Gender Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI390",
    "name": "Bachelor of Arts in Philosophy",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI391",
    "name": "Bachelor of Arts in Religious Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI392",
    "name": "Bachelor of Arts in History",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI393",
    "name": "Bachelor of Arts in Geography",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI394",
    "name": "Bachelor of Arts in Anthropology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI395",
    "name": "Bachelor of Arts in Archaeology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI396",
    "name": "Bachelor of Arts in Linguistics",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI397",
    "name": "Bachelor of Arts in English Literature",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI398",
    "name": "Bachelor of Arts in Swahili Literature",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI399",
    "name": "Bachelor of Arts in French",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI400",
    "name": "Bachelor of Arts in German",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI401",
    "name": "Bachelor of Arts in Spanish",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI402",
    "name": "Bachelor of Arts in Chinese",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI403",
    "name": "Bachelor of Arts in Arabic",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI404",
    "name": "Bachelor of Arts in Criminology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI405",
    "name": "Bachelor of Arts in Security Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 27,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI406",
    "name": "Bachelor of Arts in Conflict Resolution",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI407",
    "name": "Bachelor of Arts in Peace Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI408",
    "name": "Bachelor of Arts in Social Work",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI409",
    "name": "Bachelor of Arts in Community Development",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI410",
    "name": "Bachelor of Arts in Youth Work",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI411",
    "name": "Bachelor of Arts in Counseling",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI412",
    "name": "Bachelor of Arts in Guidance and Counseling",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 26,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI413",
    "name": "Bachelor of Arts in Music",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 23,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI414",
    "name": "Bachelor of Arts in Fine Art",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 22,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI415",
    "name": "Bachelor of Arts in Theatre Arts",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 23,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI416",
    "name": "Bachelor of Arts in Film Production",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI417",
    "name": "Bachelor of Arts in Fashion Design",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 22,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI418",
    "name": "Bachelor of Arts in Interior Design",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 23,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI419",
    "name": "Bachelor of Arts in Graphic Design",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kisii University"
    ]
  },
  {
    "id": "UNI420",
    "name": "Bachelor of Architecture",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "5 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI421",
    "name": "Bachelor of Science in Urban Planning",
    "institution": "University",
    "cluster": 2,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI422",
    "name": "Bachelor of Science in Library Science",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 24,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI423",
    "name": "Bachelor of Science in Information Science",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 25,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Strathmore University"
    ]
  },
  {
    "id": "UNI424",
    "name": "Bachelor of Science in Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI425",
    "name": "Bachelor of Science in Physics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI426",
    "name": "Bachelor of Science in Mathematics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI427",
    "name": "Bachelor of Science in Statistics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Mount Kenya University"
    ]
  },
  {
    "id": "UNI428",
    "name": "Bachelor of Science in Applied Mathematics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI429",
    "name": "Bachelor of Science in Applied Statistics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI430",
    "name": "Bachelor of Science in Pure Mathematics",
    "institution": "University",
    "cluster": 3,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Technical University of Kenya"
    ]
  },
  {
    "id": "UNI431",
    "name": "Bachelor of Science in Applied Physics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI432",
    "name": "Bachelor of Science in Applied Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Dedan Kimathi University"
    ]
  },
  {
    "id": "UNI433",
    "name": "Bachelor of Science in Industrial Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI434",
    "name": "Bachelor of Science in Analytical Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI435",
    "name": "Bachelor of Science in Organic Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Maseno University"
    ]
  },
  {
    "id": "UNI436",
    "name": "Bachelor of Science in Inorganic Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI437",
    "name": "Bachelor of Science in Physical Chemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI438",
    "name": "Bachelor of Science in Geophysics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Egerton University"
    ]
  },
  {
    "id": "UNI439",
    "name": "Bachelor of Science in Meteorology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI440",
    "name": "Bachelor of Science in Astronomy",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 34,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Pwani University"
    ]
  },
  {
    "id": "UNI441",
    "name": "Bachelor of Science in Astrophysics",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 35,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI442",
    "name": "Bachelor of Science in Geology",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 32,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "MMUST"
    ]
  },
  {
    "id": "UNI443",
    "name": "Bachelor of Science in Geochemistry",
    "institution": "University",
    "cluster": 1,
    "clusterSubjects": [
      "Mathematics",
      "Physics",
      "Chemistry",
      "Biology"
    ],
    "minClusterPoints": 33,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Graduate Professional",
      "Specialist"
    ],
    "salaryRange": "KES 50,000 - 200,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI444",
    "name": "Bachelor of Science in Geoinformatics",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI445",
    "name": "Bachelor of Science in Land Administration",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI446",
    "name": "Bachelor of Science in Disaster Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI447",
    "name": "Bachelor of Science in Emergency Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI448",
    "name": "Bachelor of Science in Crisis Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI449",
    "name": "Bachelor of Science in Waste Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI450",
    "name": "Bachelor of Science in Sanitation Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI451",
    "name": "Bachelor of Science in Water Resource Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI452",
    "name": "Bachelor of Science in Conservation Biology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI453",
    "name": "Bachelor of Science in Biodiversity Conservation",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI454",
    "name": "Bachelor of Science in Climate Change",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI455",
    "name": "Bachelor of Science in Renewable Resources",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI456",
    "name": "Bachelor of Science in Natural Resources Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI457",
    "name": "Bachelor of Science in Environmental Health",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI458",
    "name": "Bachelor of Science in Occupational Health",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI459",
    "name": "Bachelor of Science in Industrial Hygiene",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI460",
    "name": "Bachelor of Science in Sports Science",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI461",
    "name": "Bachelor of Science in Exercise Science",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI462",
    "name": "Bachelor of Science in Kinesiology",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI463",
    "name": "Bachelor of Science in Recreation Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI464",
    "name": "Bachelor of Science in Leisure Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI465",
    "name": "Bachelor of Science in Parks Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI466",
    "name": "Bachelor of Science in Adventure Tourism",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI467",
    "name": "Bachelor of Science in Ecotourism",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI468",
    "name": "Bachelor of Science in Cultural Tourism",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI469",
    "name": "Bachelor of Science in Medical Tourism",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI470",
    "name": "Bachelor of Science in Cruise Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI471",
    "name": "Bachelor of Science in Airline Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI472",
    "name": "Bachelor of Science in Airport Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI473",
    "name": "Bachelor of Science in Travel Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI474",
    "name": "Bachelor of Science in Tour Operations",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI475",
    "name": "Bachelor of Science in Destination Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI476",
    "name": "Bachelor of Science in Convention Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI477",
    "name": "Bachelor of Science in Exhibition Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI478",
    "name": "Bachelor of Science in Spa Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI479",
    "name": "Bachelor of Science in Club Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI480",
    "name": "Bachelor of Science in Casino Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI481",
    "name": "Bachelor of Science in Gaming Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI482",
    "name": "Bachelor of Science in Theatre Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI483",
    "name": "Bachelor of Science in Museum Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI484",
    "name": "Bachelor of Science in Heritage Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI485",
    "name": "Bachelor of Science in Archives Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI486",
    "name": "Bachelor of Science in Records Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI487",
    "name": "Bachelor of Science in Knowledge Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI488",
    "name": "Bachelor of Science in Content Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI489",
    "name": "Bachelor of Science in Document Management",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI490",
    "name": "Bachelor of Science in Digital Preservation",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI491",
    "name": "Bachelor of Science in Cultural Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI492",
    "name": "Bachelor of Science in Media Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI493",
    "name": "Bachelor of Science in Film Studies",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI494",
    "name": "Bachelor of Science in Broadcasting",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI495",
    "name": "Bachelor of Science in Radio Production",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI496",
    "name": "Bachelor of Science in Television Production",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  },
  {
    "id": "UNI497",
    "name": "Bachelor of Science in Video Production",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Kenyatta University"
    ]
  },
  {
    "id": "UNI498",
    "name": "Bachelor of Science in Photography",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "Moi University"
    ]
  },
  {
    "id": "UNI499",
    "name": "Bachelor of Science in Photojournalism",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "JKUAT"
    ]
  },
  {
    "id": "UNI500",
    "name": "Bachelor of Science in Documentary Film",
    "institution": "University",
    "cluster": 4,
    "clusterSubjects": [
      "Mathematics",
      "English",
      "Biology",
      "Chemistry"
    ],
    "minClusterPoints": 28,
    "minMeanGrade": "C+",
    "subjectRequirements": {
      "Mathematics": "C",
      "English": "C"
    },
    "duration": "4 years",
    "careerPaths": [
      "Specialist",
      "Manager"
    ],
    "salaryRange": "KES 50,000 - 180,000",
    "institutions": [
      "University of Nairobi"
    ]
  }
];

const kmtcPrograms = [
  {
    "id": "KMTC001",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC002",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC003",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC004",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC005",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC006",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC007",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC008",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC009",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC010",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC011",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC012",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC013",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC014",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC015",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC016",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC017",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC018",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC019",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC020",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC021",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC022",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC023",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC024",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC025",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC026",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC027",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC028",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC029",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC030",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC031",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC032",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC033",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC034",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC035",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC036",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC037",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC038",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC039",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC040",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC041",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC042",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC043",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC044",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC045",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC046",
    "name": "Diploma in Clinical Medicine",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC047",
    "name": "Diploma in Nursing",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC048",
    "name": "Diploma in Medical Lab",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC049",
    "name": "Diploma in Pharmacy",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  },
  {
    "id": "KMTC050",
    "name": "Diploma in Public Health",
    "institution": "KMTC",
    "minClusterPoints": 30,
    "minMeanGrade": "C-",
    "subjectRequirements": {
      "Biology": "C-",
      "English": "C-"
    },
    "duration": "3 years",
    "careerPaths": [
      "Medical Professional"
    ],
    "salaryRange": "KES 40,000 - 120,000",
    "institutions": [
      "KMTC Nairobi"
    ]
  }
];

const tvetPrograms = [
  {
    "id": "TVET001",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET002",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET003",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET004",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET005",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET006",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET007",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET008",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET009",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET010",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET011",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET012",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET013",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET014",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET015",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET016",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET017",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET018",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET019",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET020",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET021",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET022",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET023",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET024",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET025",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET026",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET027",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET028",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET029",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET030",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET031",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET032",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET033",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET034",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET035",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET036",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET037",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET038",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET039",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET040",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET041",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET042",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET043",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET044",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET045",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET046",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET047",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET048",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET049",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET050",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET051",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET052",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET053",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET054",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET055",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET056",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET057",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET058",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET059",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET060",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET061",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET062",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET063",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET064",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET065",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET066",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET067",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET068",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET069",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET070",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET071",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET072",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET073",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET074",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET075",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET076",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET077",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET078",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET079",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET080",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET081",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET082",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET083",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET084",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET085",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET086",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET087",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET088",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET089",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET090",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET091",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET092",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET093",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET094",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET095",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET096",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET097",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET098",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET099",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET100",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET101",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET102",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET103",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET104",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET105",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET106",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET107",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET108",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET109",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET110",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET111",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET112",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET113",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET114",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET115",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET116",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET117",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET118",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET119",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET120",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET121",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET122",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET123",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET124",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET125",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET126",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET127",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET128",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET129",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET130",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET131",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET132",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET133",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET134",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET135",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET136",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET137",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET138",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET139",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET140",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET141",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET142",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET143",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET144",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET145",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET146",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET147",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET148",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET149",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET150",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET151",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET152",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET153",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET154",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET155",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET156",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET157",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET158",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET159",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET160",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET161",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET162",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET163",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET164",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET165",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET166",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET167",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET168",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET169",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET170",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET171",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET172",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET173",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET174",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET175",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET176",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET177",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET178",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET179",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET180",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET181",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET182",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET183",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET184",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET185",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET186",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET187",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET188",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET189",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET190",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET191",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET192",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET193",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET194",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET195",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET196",
    "name": "Diploma in IT",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET197",
    "name": "Diploma in Electrical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET198",
    "name": "Diploma in Mechanical",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET199",
    "name": "Diploma in Business",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  },
  {
    "id": "TVET200",
    "name": "Diploma in Hospitality",
    "institution": "TVET",
    "minClusterPoints": 22,
    "minMeanGrade": "D+",
    "subjectRequirements": {
      "Mathematics": "D+",
      "English": "D+"
    },
    "duration": "2 years",
    "careerPaths": [
      "Technician"
    ],
    "salaryRange": "KES 30,000 - 100,000",
    "institutions": [
      "Kenya Polytechnic"
    ]
  }
];

// Export
const COMPREHENSIVE_COURSES = UNIVERSITY_COURSES;
window.COMPREHENSIVE_COURSES = COMPREHENSIVE_COURSES;
window.kmtcPrograms = kmtcPrograms;
window.tvetPrograms = tvetPrograms;
window.ALL_COURSES = [...COMPREHENSIVE_COURSES, ...kmtcPrograms, ...tvetPrograms];

// Visitor Tracking
function trackVisitor() {
    const visits = localStorage.getItem('visitCount') || 0;
    const newCount = parseInt(visits) + 1;
    localStorage.setItem('visitCount', newCount);
    localStorage.setItem('lastVisit', new Date().toISOString());
    
    // Send to global counter
    const globalVisits = localStorage.getItem('globalVisitCount') || 0;
    localStorage.setItem('globalVisitCount', parseInt(globalVisits) + 1);
}

trackVisitor();

console.log("🚀 Database loaded successfully!");
console.log("📚 University Programs:", 500);
console.log("🏥 KMTC Programs:", 50);
console.log("🔧 TVET Programs:", 200);
console.log("📊 Total Programs:", 750);
