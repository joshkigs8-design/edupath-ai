// Admin Dashboard JavaScript
// Manages the admin panel functionality

// Check authentication
if (localStorage.getItem('adminLoggedIn') !== 'true') {
    window.location.href = 'admin-login.html';
}

// Set admin name
document.getElementById('admin-name').textContent = localStorage.getItem('adminUsername') || 'Admin';

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('adminLoggedIn');
        localStorage.removeItem('adminUsername');
        window.location.href = 'admin-login.html';
    }
}

// Load statistics
function refreshStats() {
    const uniCount = window.COMPREHENSIVE_COURSES ? window.COMPREHENSIVE_COURSES.length : 0;
    const kmtcCount = window.kmtcPrograms ? window.kmtcPrograms.length : 0;
    const tvetCount = window.tvetPrograms ? window.tvetPrograms.length : 0;
    const totalCount = uniCount + kmtcCount + tvetCount;
    
    // Get visitor stats
    const globalVisits = localStorage.getItem('globalVisitCount') || 0;
    const todayVisits = getTodayVisitors();
    
    document.getElementById('uni-count').textContent = uniCount;
    document.getElementById('kmtc-count').textContent = kmtcCount;
    document.getElementById('tvet-count').textContent = tvetCount;
    document.getElementById('total-count').textContent = totalCount;
    document.getElementById('visitor-count').textContent = globalVisits;
    document.getElementById('today-visitors').textContent = todayVisits;
    
    console.log('📊 Stats refreshed:', {uniCount, kmtcCount, tvetCount, totalCount, globalVisits, todayVisits});
}

// Get today's visitors
function getTodayVisitors() {
    const today = new Date().toDateString();
    const storedDate = localStorage.getItem('visitorDate');
    const todayCount = localStorage.getItem('todayVisitorCount') || 0;
    
    if (storedDate !== today) {
        localStorage.setItem('visitorDate', today);
        localStorage.setItem('todayVisitorCount', '1');
        return 1;
    }
    return todayCount;
}

// Page switching
function switchPage(pageName) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === pageName) {
            item.classList.add('active');
        }
    });
    
    // Update pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(`${pageName}-page`).classList.add('active');
    
    // Update title
    const titles = {
        'overview': 'Dashboard Overview',
        'university': 'University Programs',
        'kmtc': 'KMTC Programs',
        'tvet': 'TVET Programs',
        'add': 'Add New Program',
        'export': 'Export Data'
    };
    document.getElementById('page-title').textContent = titles[pageName];
    
    // Load data for specific pages
    if (pageName === 'university') loadUniversityTable();
    if (pageName === 'kmtc') loadKMTCTable();
    if (pageName === 'tvet') loadTVETTable();
}

// Navigation click handlers
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        switchPage(item.dataset.page);
    });
});

// Load University Programs Table
function loadUniversityTable() {
    const tbody = document.getElementById('uni-tbody');
    tbody.innerHTML = '';
    
    const programs = window.COMPREHENSIVE_COURSES || [];
    
    programs.forEach((prog, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${prog.id}</td>
            <td>${prog.name}</td>
            <td>Cluster ${prog.cluster || 'N/A'}</td>
            <td>${prog.minMeanGrade}</td>
            <td>${prog.duration}</td>
            <td>
                <button class="btn-action btn-view" onclick="viewProgram('university', ${index})">👁️</button>
                <button class="btn-action btn-edit" onclick="editProgram('university', ${index})">✏️</button>
                <button class="btn-action btn-delete" onclick="deleteProgram('university', ${index})">🗑️</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Load KMTC Programs Table
function loadKMTCTable() {
    const tbody = document.getElementById('kmtc-tbody');
    tbody.innerHTML = '';
    
    const programs = window.kmtcPrograms || [];
    
    programs.forEach((prog, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${prog.id}</td>
            <td>${prog.name}</td>
            <td>${prog.minMeanGrade}</td>
            <td>${prog.duration}</td>
            <td>
                <button class="btn-action btn-view" onclick="viewProgram('kmtc', ${index})">👁️</button>
                <button class="btn-action btn-edit" onclick="editProgram('kmtc', ${index})">✏️</button>
                <button class="btn-action btn-delete" onclick="deleteProgram('kmtc', ${index})">🗑️</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Load TVET Programs Table
function loadTVETTable() {
    const tbody = document.getElementById('tvet-tbody');
    tbody.innerHTML = '';
    
    const programs = window.tvetPrograms || [];
    
    programs.forEach((prog, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${prog.id}</td>
            <td>${prog.name}</td>
            <td>${prog.minMeanGrade}</td>
            <td>${prog.duration}</td>
            <td>
                <button class="btn-action btn-view" onclick="viewProgram('tvet', ${index})">👁️</button>
                <button class="btn-action btn-edit" onclick="editProgram('tvet', ${index})">✏️</button>
                <button class="btn-action btn-delete" onclick="deleteProgram('tvet', ${index})">🗑️</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// View program details
function viewProgram(type, index) {
    let program;
    if (type === 'university') program = window.COMPREHENSIVE_COURSES[index];
    else if (type === 'kmtc') program = window.kmtcPrograms[index];
    else program = window.tvetPrograms[index];
    
    alert(`Program Details:\n\n${JSON.stringify(program, null, 2)}`);
}

// Edit program
function editProgram(type, index) {
    alert('Edit functionality will be implemented in the full version');
}

// Delete program
function deleteProgram(type, index) {
    if (confirm('Are you sure you want to delete this program?')) {
        alert('Delete functionality will be implemented in the full version');
    }
}

// Add program form handler
document.getElementById('add-program-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const newProgram = {
        id: 'NEW' + Date.now(),
        name: document.getElementById('prog-name').value,
        institution: document.getElementById('inst-type').value,
        minMeanGrade: document.getElementById('min-grade').value,
        duration: document.getElementById('duration').value,
        careerPaths: document.getElementById('careers').value.split(',').map(s => s.trim()),
        salaryRange: document.getElementById('salary').value
    };
    
    console.log('New program:', newProgram);
    alert('Program added successfully! (In production, this would save to database)');
    
    // Reset form
    this.reset();
});

// Export functions
function exportJSON() {
    const data = {
        university: window.COMPREHENSIVE_COURSES || [],
        kmtc: window.kmtcPrograms || [],
        tvet: window.tvetPrograms || [],
        exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `edupath-database-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

function exportCSV() {
    // Convert to CSV
    let csv = 'Type,ID,Name,Grade,Duration,Salary\n';
    
    (window.COMPREHENSIVE_COURSES || []).forEach(p => {
        csv += `University,${p.id},"${p.name}",${p.minMeanGrade},${p.duration},"${p.salaryRange}"\n`;
    });
    
    (window.kmtcPrograms || []).forEach(p => {
        csv += `KMTC,${p.id},"${p.name}",${p.minMeanGrade},${p.duration},"${p.salaryRange}"\n`;
    });
    
    (window.tvetPrograms || []).forEach(p => {
        csv += `TVET,${p.id},"${p.name}",${p.minMeanGrade},${p.duration},"${p.salaryRange}"\n`;
    });
    
    const blob = new Blob([csv], {type: 'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `edupath-database-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
}

function backupDatabase() {
    exportJSON();
    alert('✅ Database backup created successfully!');
}

// Search functionality
document.getElementById('uni-search')?.addEventListener('input', function(e) {
    filterTable('uni-tbody', e.target.value);
});

document.getElementById('kmtc-search')?.addEventListener('input', function(e) {
    filterTable('kmtc-tbody', e.target.value);
});

document.getElementById('tvet-search')?.addEventListener('input', function(e) {
    filterTable('tvet-tbody', e.target.value);
});

function filterTable(tbodyId, searchTerm) {
    const tbody = document.getElementById(tbodyId);
    const rows = tbody.getElementsByTagName('tr');
    
    for (let row of rows) {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm.toLowerCase()) ? '' : 'none';
    }
}

// Initialize on load
window.addEventListener('load', () => {
    refreshStats();
    setupBulkUpload();
    console.log('✅ Admin Dashboard Initialized');
});

// Setup bulk upload
function setupBulkUpload() {
    const fileInput = document.getElementById('bulk-upload-file');
    const uploadArea = document.getElementById('upload-area');
    const uploadStatus = document.getElementById('upload-status');
    
    if (!fileInput || !uploadArea) return;
    
    // Click to upload
    uploadArea.addEventListener('click', () => fileInput.click());
    
    // Drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--primary)';
        uploadArea.style.background = 'rgba(102, 126, 234, 0.1)';
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.style.borderColor = 'var(--border)';
        uploadArea.style.background = 'white';
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--border)';
        uploadArea.style.background = 'white';
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            processUploadedFile(files[0]);
        }
    });
    
    // File input change
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            processUploadedFile(e.target.files[0]);
        }
    });
}

// Process uploaded file
function processUploadedFile(file) {
    const uploadStatus = document.getElementById('upload-status');
    uploadStatus.style.display = 'block';
    uploadStatus.innerHTML = '<p style="color: var(--primary);">Processing file...</p>';
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            let programs = [];
            
            if (file.name.endsWith('.json')) {
                // Parse JSON
                programs = JSON.parse(e.target.result);
            } else if (file.name.endsWith('.csv')) {
                // Parse CSV
                const lines = e.target.result.split('\n');
                const headers = lines[0].split(',');
                
                for (let i = 1; i < lines.length; i++) {
                    if (lines[i].trim()) {
                        const values = lines[i].split(',');
                        const program = {};
                        headers.forEach((header, index) => {
                            program[header.trim()] = values[index]?.trim();
                        });
                        programs.push(program);
                    }
                }
            }
            
            if (programs.length > 0) {
                uploadStatus.innerHTML = `
                    <p style="color: var(--success);">✅ Successfully loaded ${programs.length} programs!</p>
                    <p style="font-size: 14px; color: #6b7280; margin-top: 8px;">
                        Preview: ${programs[0].name || programs[0].programme_name || 'Unknown'}
                    </p>
                    <button onclick="confirmBulkUpload()" class="btn-submit" style="margin-top: 10px;">
                        Add ${programs.length} Programs to Database
                    </button>
                `;
                
                // Store temporarily
                window.tempUploadedPrograms = programs;
            } else {
                uploadStatus.innerHTML = '<p style="color: var(--danger);">❌ No valid programs found in file</p>';
            }
        } catch (error) {
            uploadStatus.innerHTML = `<p style="color: var(--danger);">❌ Error: ${error.message}</p>`;
        }
    };
    
    reader.readAsText(file);
}

// Confirm bulk upload
function confirmBulkUpload() {
    if (window.tempUploadedPrograms) {
        const count = window.tempUploadedPrograms.length;
        if (confirm(`Are you sure you want to add ${count} programs to the database?`)) {
            // In production, this would save to database
            alert(`✅ ${count} programs added successfully!\n\n(In production, this would save to the database)`);
            document.getElementById('upload-status').innerHTML = 
                `<p style="color: var(--success);">✅ ${count} programs added!</p>`;
            window.tempUploadedPrograms = null;
            refreshStats();
        }
    }
}
